
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true, args: ['--no-sandbox'] }
});

client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('الراجل جهز يمعلم');
});

client.on('message', async msg => {
    if (msg.body === '٭انطر' && msg.hasQuotedMsg) {
        const quotedMsg = await msg.getQuotedMessage();
        if (msg.fromMe || msg.author === '201501728150@c.us') {
            await msg.reply('غار في داهية');
            client.removeParticipant(msg.from, quotedMsg.author);
        } else {
            msg.reply('مش بسمع غير كلام عمك لوسيفر يا متناك 😏🖕🏻');
        }
    }
});

client.initialize();
